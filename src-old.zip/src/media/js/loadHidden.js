function loadQuinButton(){
	$("#quin-button").css('display','block');
}

function loadHiddenLeft(){
	$("#left-content").css('display','block');
}

function paymentControl(){
	alert("touch me");
	/*$("#pay-button").submit(function(event){
		alert("Cant pay");
		event.preventDefault();
		return false;
	});*/
}